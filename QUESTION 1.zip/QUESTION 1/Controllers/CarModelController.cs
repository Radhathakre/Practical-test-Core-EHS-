﻿using Car_Model_Management.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Car_Model_Management.Controllers
{
    public class CarModelController : Controller
    {
        // Mock Database
        private static List<CarModel> CarModels = new List<CarModel>();

        // GET: CarModel
        public ActionResult Index(string search, string orderBy)
        {
            var models = CarModels.AsQueryable();

            // Search
            if (!string.IsNullOrEmpty(search))
            {
                models = models.Where(m => m.ModelName.Contains(search) || m.ModelCode.Contains(search));
            }

            // Order By
            if (orderBy == "DateOfManufacturing")
            {
                models = models.OrderByDescending(m => m.DateOfManufacturing);
            }
            else if (orderBy == "SortOrder")
            {
                models = models.OrderBy(m => m.SortOrder);
            }
            else
            {
                // Default sorting
                models = models.OrderByDescending(m => m.DateOfManufacturing);
            }


            return View(models.ToList());
        }

        // GET: CarModel/Create
        public ActionResult Create()
        {
            ViewBag.Brands = new List<string> { "Audi", "Jaguar", "Land Rover", "Renault" };
            ViewBag.Classes = new List<string> { "A-Class", "B-Class", "C-Class" };
            return View();
        }

        // POST: CarModel/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CarModel model, IEnumerable<HttpPostedFileBase> images)
        {
            if (ModelState.IsValid)
            {
                if (images != null)
                {
                    foreach (var image in images)
                    {
                        if (image.ContentLength > 0 && image.ContentLength <= 5 * 1024 * 1024)
                        {
                            var directory = Server.MapPath("~/Images");
                            if (!System.IO.Directory.Exists(directory))
                            {
                                System.IO.Directory.CreateDirectory(directory);
                            }

                            var path = $"~/Images/{Guid.NewGuid()}_{image.FileName}";
                            try
                            {
                                image.SaveAs(Server.MapPath(path));
                                model.Images.Add(path);
                            }
                            catch (Exception ex)
                            {
                                ModelState.AddModelError("", $"Error saving image: {ex.Message}");
                            }
                        }
                    }
                }

                CarModels.Add(model);
                return RedirectToAction("Index");
            }

            ViewBag.Brands = new List<string> { "Audi", "Jaguar", "Land Rover", "Renault" };
            ViewBag.Classes = new List<string> { "A-Class", "B-Class", "C-Class" };
            return View(model);
        }

        // Additional CRUD operations (Edit, Delete, Details) can be implemented similarly.
    }
}
