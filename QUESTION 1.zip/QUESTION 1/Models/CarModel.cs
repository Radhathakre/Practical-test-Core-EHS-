﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Car_Model_Management.Models
{
    public class CarModel
    {
        [Required]
        public string Brand { get; set; }

        [Required]
        public string Class { get; set; }

        [Required]
        public string ModelName { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z0-9]{1,10}$", ErrorMessage = "Model Code must be alphanumeric and up to 10 characters.")]
        public string ModelCode { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public string Features { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime DateOfManufacturing { get; set; }

        public bool Active { get; set; }

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "Sort-order must be a numeric value.")]
        public int SortOrder { get; set; }

        public List<string> Images { get; set; } = new List<string>();
    }
}